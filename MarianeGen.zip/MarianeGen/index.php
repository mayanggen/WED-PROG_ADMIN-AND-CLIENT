<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN PAGE</title>
</head>
<body>
    <div class="container" style="max-width: 200px; margin: 0 auto;">
        <h2>LOGIN</h2>

        <form action="authenticate.php" method="post">
            <input type="text" name="username" id="" placeholder="Enter username" required>
            <br> <br>
            <input type="text" name="password" id="" placeholder="Enter password" required>
            <br> <br>
            <input type="submit" value="Login" name="login" style= "width: 170px">
        </form>
    </div>
</body>
</html>