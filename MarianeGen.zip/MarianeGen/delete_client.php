<?php
//Start Session
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin'){
        header("Location: index.php");
        exit();
}
//include connection string
include('database/connection.php');

//Check if client ID is provided in the URL
if (isset($_GET['ID'])){
    $client_ID = $_GET['ID'];

    //Delete the client from the db
    $delete_dql = "DELETE FROM users WHERE ID = '$client_ID'";
    if($conn->query($delete_dql) === TRUE){
        header(("Location: admin_dashboard.php?deletesuccess"));
    }
    else{
        echo "Error deleting client: ".$conn->error;
    }
}
else{
    header("Location:admin_dashboard.php");
}


?> 