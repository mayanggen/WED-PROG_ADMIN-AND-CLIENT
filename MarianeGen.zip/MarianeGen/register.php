<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRATION PAGE</title>
</head>
<body>
    <h2> REGISTRATION PAGE </h2>
        <form action="register_account.php" method="post">
        <input type="text" name="firstname" id="" placeholder="Enter firstname";>
        <br> <br>
        <input type="text" name="lastname" id="" placeholder="Enter lastname";>
        <br> <br>
        <input type="text" name="username" id="" placeholder="Enter Username">
        <br> <br>
        <input type="password" name="password" id="" placeholder="Enter Password">
        <br> <br>
        <input type="submit" name="register" value="Register">
    </form>
</body>
</html>