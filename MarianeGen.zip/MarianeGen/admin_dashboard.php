<?php
    session_start();
    if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin'){
            header("Location: index.php");
            exit();
    }
    //include connection string
    include('database/connection.php');
    //Create variable for search query
    $search_query = '';
    //Check if search query is submitted
    if(isset($_GET['search'])) {
        $search_query = $conn->real_escape_string($_GET['search']);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
    <title>ADMIN DASHBOARD</title>
</head>
<body>
    <h2>WELCOME ADMIN</h2>
    <?php
    echo $_SESSION['username'];
    ?>
    <br>
    <a href="logout.php">Logout</a>
    <br> <br>
    <!--Search Form -->
    <form action="" method="get">
    <input type="text" name="search" id=""
    placeholder="Search by username"
    value="<?php echo $search_query;?>">
    <input type="submit" value="search">
    </form>
    <br>
    <table border="1" style="width: 60;">
        
    <tr>
            <td>#</td>
            <td>username</td>
            <td>firstname</td>
            <td>lastname</td>
            <td>role</td>
            <td>action</td>
        </tr>
        <?php
        //modify SQL query based on the search input
        if(!empty($search_query)){
            $sql = "SELECT * FROM users WHERE role = 'client' AND username LIKE '%$search_query%'";
            
        }
        else{
            $sql = "SELECT * FROM users WHERE role = 'client'";
        }
        //execute SQL command
        $result = $conn->query($sql);
        //Check if any client exist
        if($result->num_rows > 0){
                //Loop to display each client record
                $count=1;
                while($row = $result->fetch_assoc()){
                echo "<tr>";
                echo "<td> $count</td>";
                echo "<td>".$row['username']."</td>";
                echo "<td>".$row['firstname']."</td>";
                echo "<td>".$row['lastname']."</td>";
                echo "<td>".$row['role']."</td>";
                echo "<td>";
                echo "<a href='edit_client.php?ID=".$row['ID']."'>Edit</a> ";
                echo "<a href='delete_client.php?ID=".$row['ID']."'on click='return confirm(\"Are you syur you want to dilit this client?\");'>Delete</a>";
                echo "</td>";
                echo "</tr>";
                $count++;
                }
        }
        else{
            echo"<tr> <td colspan=5> NO Records Found!</td></tr>";
        }
        ?>
    </table>
</body>
</html>